from gpiozero import InputDevice, OutputDevice, LED
from time import sleep, time
import numpy as np
import argparse
import cv2
from picamera import PiCamera
from subprocess import call

def get_red(image_dest, numpix, pin, res_l, res_h):
    
    lower_r = [17, 15, 100]
    upper_r = [50, 56, 200]
    lower_r = np.array(lower_r, dtype = "uint8")
    upper_r = np.array(upper_r, dtype = "uint8")
    
    camera = PiCamera()
    camera.resolution = (res_l, res_h)
#
    camera_led = LED(pin)
    camera.capture(image_dest,format='png')
    image = cv2.imread(image_dest)

    mask = cv2.inRange(image, lower_r, upper_r)
    output = cv2.bitwise_and(image, image, mask = mask)

    row,col,channel= output.shape
    print (" row  = ",row)
    print (" col  = ",col)
    red = 0
    for i in range(row):
        for j in range(col):
            red = red + output[i,j,2]
       
    print ("red = ",red)
    call(["rm", image_dest])

    if red > numpix :
        camera_led.on()
        # go_forward
    else:
        camera_led.off()
    
# show the images
    cv2.imshow("images", np.hstack([image, output]))
    cv2.waitKey(0)
##
    return red

###########################################################
# Name
# arg1 = echo pin
# arg2 = trigger pin
# Descriptio ; what does it do 
###########################################################

def get_pulse_time(trig_pin, echo_pin):
    ###### Add your echo and
    trig = OutputDevice(trig_pin)
    echo = InputDevice(echo_pin)
    trig.on()
    sleep(0.00001)
    trig.off()
    while echo.is_active == False:
            pulse_start = time()

    while echo.is_active == True:
            pulse_end = time()

    sleep(0.06)

    return pulse_end - pulse_start

def calculate_distance(duration):
    speed = 343
    distance = speed * duration / 2
    return distance

#################
def uds_hit(trig_pin, echo_pin, uds_pin):
    uds_led = LED(uds_pin)
    duration = get_pulse_time(trig_pin, echo_pin)
    distance = calculate_distance(duration)
    distance_cm = distance*100
    ds_int = int(distance_cm)
    print(ds_int, 'cm')
    my_val = 0
    if ds_int < 10 :
        uds_led.on()
        my_val = 1
    else:
        uds_led.off()
    return my_val
