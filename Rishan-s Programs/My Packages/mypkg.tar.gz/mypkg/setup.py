from setuptools import setup
setup(name='mypkg',
      version='0.3',
      description='a library for CERCBot for Pi Wars',
      url='to be done',
      author='Rish the fish',
      author_email='rish@fish.com',
      license='Daddy',
      packages=['mypkg'],
      zip_safe=False)
